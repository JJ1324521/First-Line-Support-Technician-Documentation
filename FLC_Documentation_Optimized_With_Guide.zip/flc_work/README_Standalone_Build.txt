FLC TECHNICIAN DOCUMENTATION SYSTEM — OPTIMIZED SOURCE

CONTENTS
- FLC_Documentation.py: Python/Tkinter application source.
- Build_FLC_Standalone.bat: Windows one-click EXE builder.
- requirements.txt: runtime dependency list.

FEATURES
- Customer/site/service fault documentation.
- ONT(Fibre) and LTE service workflows.
- Troubleshooting checklists, escalation details, customer updates and timeline.
- SQLite fault history and dashboard.
- PDF export and standalone Windows EXE build support.

IMPROVEMENTS IN THIS VERSION
- Saves and restores individual troubleshooting checkbox states with each fault.
- Automatically migrates existing flc_database.db files by adding the new check_states column;
  existing fault records are retained.
- Adds SQLite indexes for status and creation date to help history/dashboard queries.
- Escapes user-entered text before inserting it into ReportLab paragraphs, preventing special
  characters such as < and & from breaking PDF generation.
- Restricts service-specific workflow logic to the supported ONT(Fibre) and LTE options.

RUN FROM SOURCE
1. Install Python 3.10 or newer.
2. Open a terminal in this folder and run:
   python -m pip install -r requirements.txt
3. Run:
   python FLC_Documentation.py

BUILD A STANDALONE WINDOWS APP
1. On a Windows PC, extract all files into a folder.
2. Install Python 3.10 or newer and enable "Add Python to PATH".
3. Double-click Build_FLC_Standalone.bat.
4. The EXE will be created at dist\FLC_Documentation.exe.

DATA / BACKUPS
The application stores fault records in flc_database.db beside the script or EXE. Back up this
file regularly. Keep it with the EXE to retain the fault history. The database migration is
automatic and does not intentionally delete existing records.

NOTES
- The EXE must be built on Windows to produce a native Windows executable.
- The first build requires internet access to install PyInstaller and ReportLab.
- Tkinter is included with most standard Windows Python installations.
