@echo off
setlocal
cd /d "%~dp0"
title Build FLC Technician Documentation System

echo ================================================
echo   FLC Technician Documentation - EXE Builder
echo ================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python was not found.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
        echo During installation, enable "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PY=python"
)

echo Installing build dependencies...
%PY% -m pip install --upgrade pip
if errorlevel 1 goto failed
%PY% -m pip install pyinstaller reportlab
if errorlevel 1 goto failed

echo.
echo Building the standalone application...
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name FLC_Documentation --collect-all reportlab FLC_Documentation.py
if errorlevel 1 goto failed

echo.
echo SUCCESS! Your standalone application is here:
echo %CD%\dist\FLC_Documentation.exe
echo.
echo The database will be stored beside the EXE as flc_database.db.
echo Keep that database file to preserve saved records.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Check the error messages above.
pause
exit /b 1
