import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import json
import os
import sys
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from xml.sax.saxutils import escape

# ============================================================
# FLC DOCUMENTATION SYSTEM V2
# ============================================================

# Keep the database beside the executable/script so the app is portable.
APP_DIR = os.path.dirname(
    sys.executable if getattr(sys, "frozen", False)
    else os.path.abspath(__file__)
)
DATABASE = os.path.join(APP_DIR, "flc_database.db")

class FLCApp:

    def __init__(self, root):
        self.root = root

        self.root.title("FLC Technician Documentation System V2")
        self.root.geometry("1250x850")
        self.root.minsize(1050, 700)

        self.current_fault_id = None
        self.timeline = []

        self.create_database()
        self.create_variables()
        self.create_styles()
        self.create_interface()

    # ========================================================
    # DATABASE
    # ========================================================

    def create_database(self):

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS faults (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created TEXT,
                customer TEXT,
                site TEXT,
                account TEXT,
                reference TEXT,
                service_type TEXT,
                fault_type TEXT,
                start_time TEXT,
                affected_devices TEXT,
                status TEXT,
                escalated_to TEXT,
                ticket_number TEXT,
                service_notes TEXT,
                technician_notes TEXT,
                customer_communication TEXT,
                timeline TEXT,
                completion INTEGER,
                check_states TEXT NOT NULL DEFAULT '{}'
            )
        """)

        # Migrate existing databases safely without losing saved faults.
        columns = {row[1] for row in cursor.execute("PRAGMA table_info(faults)")}
        if "check_states" not in columns:
            cursor.execute("ALTER TABLE faults ADD COLUMN check_states TEXT NOT NULL DEFAULT '{}'")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_faults_status ON faults(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_faults_created ON faults(created)")
        conn.commit()
        conn.close()

    # ========================================================
    # VARIABLES
    # ========================================================

    def create_variables(self):

        self.customer = tk.StringVar()
        self.site = tk.StringVar()
        self.account = tk.StringVar()
        self.reference = tk.StringVar()

        self.service_type = tk.StringVar(value="ONT(Fibre)")
        self.fault_type = tk.StringVar(value="No Internet")

        self.start_time = tk.StringVar(
            value=datetime.now().strftime("%Y-%m-%d %H:%M")
        )

        self.affected_devices = tk.StringVar(
            value="All devices"
        )

        self.status = tk.StringVar(value="Open")
        self.escalated_to = tk.StringVar(value="None")
        self.ticket_number = tk.StringVar()

        self.completion = tk.IntVar(value=0)

        self.checks = {}

        self.general_checks = [
            "Customer/site details confirmed",
            "Affected service/account confirmed",
            "Fault symptoms confirmed",
            "Fault start time confirmed",
            "Power supply checked",
            "Cables checked",
            "Equipment physically inspected",
            "Power cycle completed",
            "Internet connection tested",
            "Multiple devices tested",
        ]

        self.ont_checks = [
            "ONT power checked",
            "ONT Power LED checked",
            "ONT PON/Online LED checked",
            "ONT LOS LED checked",
            "ONT LAN/Ethernet LED checked",
            "Fibre cable checked",
            "Ethernet cable checked",
            "ONT power cycle completed",
        ]

        self.lte_checks = [
            "LTE router power checked",
            "SIM checked",
            "LTE signal checked",
            "Antenna connections checked",
            "Ethernet cable checked",
            "LTE account/data checked",
            "SIM refresh performed",
            "LTE equipment power cycle completed",
        ]

        self.mikrotik_checks = [
            "MikroTik power checked",
            "WAN cable checked",
            "LAN ports checked",
            "WAN status checked",
            "Internet connectivity checked",
            "Wi-Fi checked",
            "CAP/CAPsMAN status checked",
            "MikroTik reboot performed",
        ]

        self.network_checks = [
            "Axxess checked",
            "Orca checked",
            "PacketSky checked",
            "Known outage checked",
        ]

        all_checks = (
            self.general_checks
            + self.ont_checks
            + self.lte_checks
            + self.mikrotik_checks
            + self.network_checks
        )

        for item in all_checks:
            self.checks[item] = tk.BooleanVar()

    # ========================================================
    # STYLING
    # ========================================================

    def create_styles(self):

        style = ttk.Style()

        try:
            style.theme_use("clam")
        except:
            pass

        style.configure(
            "Title.TLabel",
            font=("Arial", 22, "bold")
        )

        style.configure(
            "Section.TLabel",
            font=("Arial", 13, "bold")
        )

        style.configure(
            "Action.TButton",
            font=("Arial", 10, "bold"),
            padding=8
        )

    # ========================================================
    # MAIN INTERFACE
    # ========================================================

    def create_interface(self):

        # Header
        header = tk.Frame(
            self.root,
            bg="#1f2937",
            height=75
        )
        header.pack(fill="x")

        tk.Label(
            header,
            text="FLC TECHNICIAN",
            bg="#1f2937",
            fg="white",
            font=("Arial", 22, "bold")
        ).pack(side="left", padx=20)

        tk.Label(
            header,
            text="Fault & Service Documentation System V2",
            bg="#1f2937",
            fg="#d1d5db",
            font=("Arial", 10)
        ).pack(side="left")

        # Top navigation
        nav = tk.Frame(self.root)
        nav.pack(fill="x", padx=10, pady=8)

        buttons = [
            ("New Fault", self.new_fault),
            ("Dashboard", self.dashboard),
            ("Fault History", self.history),
            ("Save Fault", self.save_fault),
            ("Generate Report", self.show_documentation),
            ("Export PDF", self.export_pdf),
        ]

        for text, command in buttons:
            ttk.Button(
                nav,
                text=text,
                command=command,
                style="Action.TButton"
            ).pack(side="left", padx=4)

        # Main scrollable area
        outer = tk.Frame(self.root)
        outer.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(outer)
        scrollbar = ttk.Scrollbar(
            outer,
            orient="vertical",
            command=self.canvas.yview
        )

        self.main_frame = tk.Frame(self.canvas)

        self.main_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.create_window(
            (0, 0),
            window=self.main_frame,
            anchor="nw"
        )

        self.canvas.configure(
            yscrollcommand=scrollbar.set
        )

        self.canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        self.build_form()

    # ========================================================
    # FORM
    # ========================================================

    def clear_main_frame(self):

        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def build_form(self):

        self.clear_main_frame()

        self.customer_section()
        self.fault_section()
        self.workflow_section()
        self.service_section()
        self.timeline_section()
        self.escalation_section()
        self.notes_section()
        self.quick_actions()

        self.update_completion()

    # ========================================================
    # SECTION
    # ========================================================

    def section(self, title):

        frame = tk.Frame(
            self.main_frame,
            bg="#374151"
        )

        frame.pack(
            fill="x",
            padx=15,
            pady=(15, 5)
        )

        tk.Label(
            frame,
            text=title,
            bg="#374151",
            fg="white",
            font=("Arial", 12, "bold")
        ).pack(
            anchor="w",
            padx=10,
            pady=7
        )

    def entry(self, label, variable):

        frame = tk.Frame(self.main_frame)
        frame.pack(
            fill="x",
            padx=25,
            pady=4
        )

        tk.Label(
            frame,
            text=label,
            width=25,
            anchor="w",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        ttk.Entry(
            frame,
            textvariable=variable,
            width=70
        ).pack(
            side="left",
            fill="x",
            expand=True
        )

    # ========================================================
    # CUSTOMER
    # ========================================================

    def customer_section(self):

        self.section(
            "1. CUSTOMER / SERVICE DETAILS"
        )

        self.entry(
            "Customer Name:",
            self.customer
        )

        self.entry(
            "Site Name:",
            self.site
        )

        self.entry(
            "Account / Service:",
            self.account
        )

        self.entry(
            "Reference Number:",
            self.reference
        )

    # ========================================================
    # FAULT
    # ========================================================

    def fault_section(self):

        self.section(
            "2. FAULT IDENTIFICATION"
        )

        frame = tk.Frame(self.main_frame)
        frame.pack(
            fill="x",
            padx=25,
            pady=5
        )

        tk.Label(
            frame,
            text="Service Type:",
            width=25,
            anchor="w",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        service = ttk.Combobox(
            frame,
            textvariable=self.service_type,
            values=["ONT(Fibre)", "LTE"],
            state="readonly",
            width=35
        )

        service.pack(side="left")

        service.bind(
            "<<ComboboxSelected>>",
            lambda e: self.build_form()
        )

        frame2 = tk.Frame(self.main_frame)
        frame2.pack(
            fill="x",
            padx=25,
            pady=5
        )

        tk.Label(
            frame2,
            text="Fault Type:",
            width=25,
            anchor="w",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        ttk.Combobox(
            frame2,
            textvariable=self.fault_type,
            values=[
                "No Internet",
                "Slow Internet",
                "Intermittent Connection",
                "Wi-Fi Issue",
                "Fibre Outage",
                "LTE Outage",
                "Router Issue",
                "Other"
            ],
            width=35
        ).pack(side="left")

        self.entry(
            "Fault Started:",
            self.start_time
        )

        self.entry(
            "Affected Devices:",
            self.affected_devices
        )

    # ========================================================
    # DYNAMIC WORKFLOW
    # ========================================================

    def workflow_section(self):

        self.section(
            "3. FLC WORKFLOW"
        )

        frame = tk.Frame(
            self.main_frame
        )

        frame.pack(
            fill="x",
            padx=25
        )

        # General
        tk.Label(
            frame,
            text="GENERAL FLC CHECKS",
            font=("Arial", 10, "bold")
        ).pack(anchor="w")

        self.create_checkboxes(
            frame,
            self.general_checks
        )

        # Dynamic service checks
        service = self.service_type.get()

        if service == "ONT(Fibre)":

            tk.Label(
                frame,
                text="ONT / FIBRE CHECKS",
                font=("Arial", 10, "bold")
            ).pack(
                anchor="w",
                pady=(12, 0)
            )

            self.create_checkboxes(
                frame,
                self.ont_checks
            )

        if service == "LTE":

            tk.Label(
                frame,
                text="LTE CHECKS",
                font=("Arial", 10, "bold")
            ).pack(
                anchor="w",
                pady=(12, 0)
            )

            self.create_checkboxes(
                frame,
                self.lte_checks
            )

        if service == "MikroTik / Router":

            tk.Label(
                frame,
                text="MIKROTIK / ROUTER CHECKS",
                font=("Arial", 10, "bold")
            ).pack(
                anchor="w",
                pady=(12, 0)
            )

            self.create_checkboxes(
                frame,
                self.mikrotik_checks
            )

        # Network systems
        tk.Label(
            frame,
            text="NETWORK / PROVIDER CHECKS",
            font=("Arial", 10, "bold")
        ).pack(
            anchor="w",
            pady=(12, 0)
        )

        self.create_checkboxes(
            frame,
            self.network_checks
        )

    def create_checkboxes(self, parent, items):

        grid = tk.Frame(parent)
        grid.pack(fill="x")

        for index, item in enumerate(items):

            row = index // 2
            column = index % 2

            tk.Checkbutton(
                grid,
                text=item,
                variable=self.checks[item],
                command=self.update_completion,
                anchor="w"
            ).grid(
                row=row,
                column=column,
                sticky="w",
                padx=10,
                pady=3
            )

        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

    # ========================================================
    # SERVICE NOTES
    # ========================================================

    def service_section(self):

        self.section(
            "4. SERVICE-SPECIFIC FINDINGS"
        )

        self.service_notes = tk.Text(
            self.main_frame,
            height=7,
            wrap="word"
        )

        self.service_notes.pack(
            fill="x",
            padx=25,
            pady=5
        )

        hint = (
            "Examples:\n"
            "Fibre: ONT LOS red. PacketSky escalation required.\n"
            "LTE: Account active, data available, SIM refresh completed.\n"
            "MikroTik: WAN port has no link."
        )

        tk.Label(
            self.main_frame,
            text=hint,
            fg="#6b7280",
            justify="left"
        ).pack(
            anchor="w",
            padx=25
        )

    # ========================================================
    # TIMELINE
    # ========================================================

    def timeline_section(self):

        self.section(
            "5. FAULT TIMELINE"
        )

        frame = tk.Frame(self.main_frame)
        frame.pack(
            fill="x",
            padx=25
        )

        self.timeline_list = tk.Listbox(
            frame,
            height=7
        )

        self.timeline_list.pack(
            side="left",
            fill="both",
            expand=True
        )

        button_frame = tk.Frame(frame)
        button_frame.pack(
            side="right",
            padx=10
        )

        actions = [
            "Fault Received",
            "Troubleshooting Started",
            "Power Cycle",
            "Internet Test",
            "Axxess Checked",
            "Orca Checked",
            "PacketSky Escalated",
            "Customer Updated",
            "Fault Resolved",
        ]

        for action in actions:

            ttk.Button(
                button_frame,
                text=action,
                command=lambda a=action: self.add_timeline(a)
            ).pack(
                fill="x",
                pady=2
            )

    def add_timeline(self, action):

        timestamp = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        entry = f"{timestamp} - {action}"

        self.timeline.append(entry)

        self.timeline_list.insert(
            tk.END,
            entry
        )

    # ========================================================
    # ESCALATION
    # ========================================================

    def escalation_section(self):

        self.section(
            "6. ESCALATION / STATUS"
        )

        frame = tk.Frame(self.main_frame)
        frame.pack(
            fill="x",
            padx=25,
            pady=5
        )

        tk.Label(
            frame,
            text="Status:",
            width=25,
            anchor="w",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        ttk.Combobox(
            frame,
            textvariable=self.status,
            values=[
                "Open",
                "Resolved",
                "Monitoring",
                "Escalated",
                "Awaiting Customer",
                "Awaiting FNO / Provider"
            ],
            state="readonly",
            width=35
        ).pack(side="left")

        frame2 = tk.Frame(self.main_frame)
        frame2.pack(
            fill="x",
            padx=25,
            pady=5
        )

        tk.Label(
            frame2,
            text="Escalated To:",
            width=25,
            anchor="w",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        ttk.Combobox(
            frame2,
            textvariable=self.escalated_to,
            values=[
                "None",
                "PacketSky",
                "Orca",
                "Axxess",
                "Network Team",
                "Field Technician",
                "Other"
            ],
            width=35
        ).pack(side="left")

        self.entry(
            "Ticket / Escalation No.:",
            self.ticket_number
        )

        # Completion
        completion_frame = tk.Frame(
            self.main_frame
        )

        completion_frame.pack(
            fill="x",
            padx=25,
            pady=10
        )

        tk.Label(
            completion_frame,
            text="FLC Completion:",
            font=("Arial", 10, "bold")
        ).pack(side="left")

        self.progress = ttk.Progressbar(
            completion_frame,
            orient="horizontal",
            length=400,
            mode="determinate"
        )

        self.progress.pack(
            side="left",
            padx=10
        )

        self.completion_label = tk.Label(
            completion_frame,
            text="0%"
        )

        self.completion_label.pack(
            side="left"
        )

    # ========================================================
    # NOTES
    # ========================================================

    def notes_section(self):

        self.section(
            "7. TECHNICIAN NOTES / CUSTOMER COMMUNICATION"
        )

        tk.Label(
            self.main_frame,
            text="Technician Findings:",
            font=("Arial", 10, "bold")
        ).pack(
            anchor="w",
            padx=25
        )

        self.notes = tk.Text(
            self.main_frame,
            height=7,
            wrap="word"
        )

        self.notes.pack(
            fill="x",
            padx=25,
            pady=5
        )

        tk.Label(
            self.main_frame,
            text="Customer Communication:",
            font=("Arial", 10, "bold")
        ).pack(
            anchor="w",
            padx=25
        )

        self.customer_communication = tk.Text(
            self.main_frame,
            height=6,
            wrap="word"
        )

        self.customer_communication.pack(
            fill="x",
            padx=25,
            pady=5
        )

    # ========================================================
    # QUICK ACTIONS
    # ========================================================

    def quick_actions(self):

        self.section(
            "8. QUICK ACTIONS"
        )

        frame = tk.Frame(
            self.main_frame
        )

        frame.pack(
            padx=25,
            pady=10
        )

        buttons = [
            ("Power Cycle", "Power Cycle"),
            ("Internet Test", "Internet Test"),
            ("Axxess Check", "Axxess Checked"),
            ("Orca Check", "Orca Checked"),
            ("PacketSky Escalation", "PacketSky Escalated"),
            ("Customer Updated", "Customer Updated"),
            ("Mark Resolved", "Fault Resolved"),
        ]

        for text, action in buttons:

            ttk.Button(
                frame,
                text=text,
                command=lambda a=action: self.quick_action(a)
            ).pack(
                side="left",
                padx=3
            )

    def quick_action(self, action):

        self.add_timeline(action)

        if action == "Fault Resolved":
            self.status.set("Resolved")

        elif action == "PacketSky Escalated":
            self.escalated_to.set("PacketSky")
            self.status.set("Escalated")

        elif action == "Customer Updated":

            current = self.customer_communication.get(
                "1.0",
                tk.END
            ).strip()

            if not current:
                self.customer_communication.insert(
                    "1.0",
                    "Customer was updated regarding the current fault status."
                )

    # ========================================================
    # COMPLETION
    # ========================================================

    def update_completion(self):

        service = self.service_type.get()

        active = list(self.general_checks)

        if service == "ONT(Fibre)":
            active += self.ont_checks

        elif service == "LTE":
            active += self.lte_checks

        elif service == "MikroTik / Router":
            active += self.mikrotik_checks

        active += self.network_checks

        if not active:
            percentage = 0
        else:

            completed = sum(
                1
                for item in active
                if self.checks[item].get()
            )

            percentage = int(
                (completed / len(active)) * 100
            )

        self.completion.set(
            percentage
        )

        if hasattr(self, "progress"):

            self.progress["value"] = percentage

            self.completion_label.config(
                text=f"{percentage}%"
            )

    # ========================================================
    # BUILD DOCUMENTATION
    # ========================================================

    def build_documentation(self):

        checked = [
            item
            for item, variable in self.checks.items()
            if variable.get()
        ]

        service_notes = self.service_notes.get(
            "1.0",
            tk.END
        ).strip()

        notes = self.notes.get(
            "1.0",
            tk.END
        ).strip()

        communication = self.customer_communication.get(
            "1.0",
            tk.END
        ).strip()

        timeline = "\n".join(
            self.timeline
        )

        return f"""
============================================================
                 FLC FAULT DOCUMENTATION
============================================================

DATE / TIME:
{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

CUSTOMER:
{self.customer.get()}

SITE:
{self.site.get()}

ACCOUNT / SERVICE:
{self.account.get()}

REFERENCE:
{self.reference.get()}

SERVICE TYPE:
{self.service_type.get()}

FAULT TYPE:
{self.fault_type.get()}

FAULT STARTED:
{self.start_time.get()}

AFFECTED DEVICES:
{self.affected_devices.get()}

------------------------------------------------------------
FLC COMPLETION
------------------------------------------------------------

{self.completion.get()}%

------------------------------------------------------------
TROUBLESHOOTING COMPLETED
------------------------------------------------------------

{chr(10).join("[✓] " + x for x in checked)}

------------------------------------------------------------
SERVICE-SPECIFIC FINDINGS
------------------------------------------------------------

{service_notes or "No additional findings recorded."}

------------------------------------------------------------
FAULT TIMELINE
------------------------------------------------------------

{timeline or "No timeline events recorded."}

------------------------------------------------------------
TECHNICIAN FINDINGS
------------------------------------------------------------

{notes or "No technician notes recorded."}

------------------------------------------------------------
ESCALATION
------------------------------------------------------------

STATUS:
{self.status.get()}

ESCALATED TO:
{self.escalated_to.get()}

TICKET / ESCALATION NUMBER:
{self.ticket_number.get() or "N/A"}

------------------------------------------------------------
CUSTOMER COMMUNICATION
------------------------------------------------------------

{communication or "No customer communication recorded."}

============================================================
                    END OF REPORT
============================================================
"""

    # ========================================================
    # CUSTOMER UPDATE
    # ========================================================

    def generate_customer_update(self):

        if self.status.get() == "Resolved":

            return (
                f"Hi, your reported connectivity issue has been "
                f"resolved. We have completed the necessary "
                f"troubleshooting and confirmed the service is "
                f"operational."
            )

        if self.status.get() in [
            "Escalated",
            "Awaiting FNO / Provider"
        ]:

            provider = self.escalated_to.get()

            return (
                f"Hi, we have completed our initial troubleshooting "
                f"and escalated the issue to {provider}. They are "
                f"currently investigating the fault. We will provide "
                f"an update once we receive further information."
            )

        return (
            "Hi, we are currently investigating the reported "
            "connectivity issue and will provide an update once "
            "we have completed the necessary checks."
        )

    # ========================================================
    # TICKET TEXT
    # ========================================================

    def generate_ticket_text(self):

        return f"""FLC COMPLETED

Customer: {self.customer.get()}
Site: {self.site.get()}
Service: {self.service_type.get()}
Fault: {self.fault_type.get()}

FLC Checks:
{self.completion.get()}% completed.

Troubleshooting:
{self.notes.get("1.0", tk.END).strip()}

Service Findings:
{self.service_notes.get("1.0", tk.END).strip()}

Status:
{self.status.get()}

Escalated To:
{self.escalated_to.get()}

Reference:
{self.ticket_number.get() or "N/A"}

Customer Communication:
{self.customer_communication.get("1.0", tk.END).strip()}
"""

    # ========================================================
    # SHOW DOCUMENTATION
    # ========================================================

    def show_documentation(self):

        window = tk.Toplevel(
            self.root
        )

        window.title(
            "FLC Documentation"
        )

        window.geometry(
            "950x750"
        )

        notebook = ttk.Notebook(
            window
        )

        notebook.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        # Report
        report_frame = tk.Frame(
            notebook
        )

        notebook.add(
            report_frame,
            text="Full Report"
        )

        report = tk.Text(
            report_frame,
            wrap="word",
            font=("Consolas", 10)
        )

        report.pack(
            fill="both",
            expand=True
        )

        report.insert(
            "1.0",
            self.build_documentation()
        )

        # Ticket
        ticket_frame = tk.Frame(
            notebook
        )

        notebook.add(
            ticket_frame,
            text="Ticket Text"
        )

        ticket = tk.Text(
            ticket_frame,
            wrap="word",
            font=("Consolas", 10)
        )

        ticket.pack(
            fill="both",
            expand=True
        )

        ticket.insert(
            "1.0",
            self.generate_ticket_text()
        )

        # Customer
        customer_frame = tk.Frame(
            notebook
        )

        notebook.add(
            customer_frame,
            text="Customer Update"
        )

        customer = tk.Text(
            customer_frame,
            wrap="word",
            font=("Arial", 11)
        )

        customer.pack(
            fill="both",
            expand=True
        )

        customer.insert(
            "1.0",
            self.generate_customer_update()
        )

        # Buttons
        buttons = tk.Frame(
            window
        )

        buttons.pack(
            pady=10
        )

        ttk.Button(
            buttons,
            text="Copy Full Report",
            command=lambda: self.copy_text(
                self.build_documentation()
            )
        ).pack(
            side="left",
            padx=5
        )

        ttk.Button(
            buttons,
            text="Copy Ticket",
            command=lambda: self.copy_text(
                self.generate_ticket_text()
            )
        ).pack(
            side="left",
            padx=5
        )

        ttk.Button(
            buttons,
            text="Copy Customer Update",
            command=lambda: self.copy_text(
                self.generate_customer_update()
            )
        ).pack(
            side="left",
            padx=5
        )

    # ========================================================
    # COPY
    # ========================================================

    def copy_text(self, text):

        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()

        messagebox.showinfo(
            "Copied",
            "Text copied to clipboard."
        )

    # ========================================================
    # SAVE FAULT
    # ========================================================

    def save_fault(self):

        if not self.customer.get() and not self.site.get():

            messagebox.showwarning(
                "Missing Information",
                "Please enter at least a customer or site."
            )

            return

        timeline = "\n".join(
            self.timeline
        )

        conn = sqlite3.connect(
            DATABASE
        )

        cursor = conn.cursor()

        data = (
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            self.customer.get(),
            self.site.get(),
            self.account.get(),
            self.reference.get(),
            self.service_type.get(),
            self.fault_type.get(),
            self.start_time.get(),
            self.affected_devices.get(),
            self.status.get(),
            self.escalated_to.get(),
            self.ticket_number.get(),
            self.service_notes.get(
                "1.0",
                tk.END
            ).strip(),
            self.notes.get(
                "1.0",
                tk.END
            ).strip(),
            self.customer_communication.get(
                "1.0",
                tk.END
            ).strip(),
            timeline,
            self.completion.get(),
            json.dumps({name: var.get() for name, var in self.checks.items()}, separators=(",", ":"))
        )

        if self.current_fault_id:

            cursor.execute("""
                UPDATE faults SET
                    created=?,
                    customer=?,
                    site=?,
                    account=?,
                    reference=?,
                    service_type=?,
                    fault_type=?,
                    start_time=?,
                    affected_devices=?,
                    status=?,
                    escalated_to=?,
                    ticket_number=?,
                    service_notes=?,
                    technician_notes=?,
                    customer_communication=?,
                    timeline=?,
                    completion=?,
                    check_states=?
                WHERE id=?
            """, data + (self.current_fault_id,))

        else:

            cursor.execute("""
                INSERT INTO faults (
                    created,
                    customer,
                    site,
                    account,
                    reference,
                    service_type,
                    fault_type,
                    start_time,
                    affected_devices,
                    status,
                    escalated_to,
                    ticket_number,
                    service_notes,
                    technician_notes,
                    customer_communication,
                    timeline,
                    completion,
                    check_states
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, data)

            self.current_fault_id = cursor.lastrowid

        conn.commit()
        conn.close()

        messagebox.showinfo(
            "Saved",
            f"Fault saved successfully.\n\n"
            f"Record ID: {self.current_fault_id}"
        )

    # ========================================================
    # HISTORY
    # ========================================================

    def history(self):

        window = tk.Toplevel(
            self.root
        )

        window.title(
            "FLC Fault History"
        )

        window.geometry(
            "1100x650"
        )

        search_frame = tk.Frame(
            window
        )

        search_frame.pack(
            fill="x",
            padx=10,
            pady=10
        )

        search_var = tk.StringVar()

        tk.Label(
            search_frame,
            text="Search:"
        ).pack(
            side="left"
        )

        ttk.Entry(
            search_frame,
            textvariable=search_var,
            width=50
        ).pack(
            side="left",
            padx=10
        )

        tree = ttk.Treeview(
            window,
            columns=(
                "ID",
                "Date",
                "Customer",
                "Site",
                "Service",
                "Fault",
                "Status",
                "Ticket",
                "Completion"
            ),
            show="headings"
        )

        headings = {
            "ID": "ID",
            "Date": "Date",
            "Customer": "Customer",
            "Site": "Site",
            "Service": "Service",
            "Fault": "Fault",
            "Status": "Status",
            "Ticket": "Ticket",
            "Completion": "FLC %"
        }

        for col, title in headings.items():

            tree.heading(
                col,
                text=title
            )

            tree.column(
                col,
                width=110
            )

        tree.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=5
        )

        def load_records():

            for item in tree.get_children():
                tree.delete(item)

            search = search_var.get().strip()

            conn = sqlite3.connect(
                DATABASE
            )

            cursor = conn.cursor()

            if search:

                cursor.execute("""
                    SELECT
                        id,
                        created,
                        customer,
                        site,
                        service_type,
                        fault_type,
                        status,
                        ticket_number,
                        completion
                    FROM faults
                    WHERE
                        customer LIKE ?
                        OR site LIKE ?
                        OR account LIKE ?
                        OR reference LIKE ?
                        OR ticket_number LIKE ?
                    ORDER BY id DESC
                """, (
                    f"%{search}%",
                    f"%{search}%",
                    f"%{search}%",
                    f"%{search}%",
                    f"%{search}%"
                ))

            else:

                cursor.execute("""
                    SELECT
                        id,
                        created,
                        customer,
                        site,
                        service_type,
                        fault_type,
                        status,
                        ticket_number,
                        completion
                    FROM faults
                    ORDER BY id DESC
                """)

            records = cursor.fetchall()

            conn.close()

            for record in records:

                tree.insert(
                    "",
                    tk.END,
                    values=record
                )

        def open_selected():

            selected = tree.selection()

            if not selected:
                messagebox.showwarning(
                    "Select Fault",
                    "Please select a fault."
                )
                return

            values = tree.item(
                selected[0]
            )["values"]

            self.load_fault(
                values[0]
            )

            window.destroy()

        ttk.Button(
            search_frame,
            text="Search",
            command=load_records
        ).pack(
            side="left"
        )

        ttk.Button(
            search_frame,
            text="Open Selected",
            command=open_selected
        ).pack(
            side="left",
            padx=5
        )

        load_records()

    # ========================================================
    # LOAD FAULT
    # ========================================================

    def load_fault(self, fault_id):

        conn = sqlite3.connect(
            DATABASE
        )

        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, created, customer, site, account, reference, service_type,
                   fault_type, start_time, affected_devices, status, escalated_to,
                   ticket_number, service_notes, technician_notes,
                   customer_communication, timeline, completion, check_states
            FROM faults WHERE id=?
        """, (fault_id,))

        record = cursor.fetchone()

        conn.close()

        if not record:
            return

        (
            record_id,
            created,
            customer,
            site,
            account,
            reference,
            service_type,
            fault_type,
            start_time,
            affected_devices,
            status,
            escalated_to,
            ticket_number,
            service_notes,
            technician_notes,
            customer_communication,
            timeline,
            completion,
            check_states
        ) = record

        self.current_fault_id = record_id

        self.customer.set(customer or "")
        self.site.set(site or "")
        self.account.set(account or "")
        self.reference.set(reference or "")

        self.service_type.set(
            "LTE" if service_type == "LTE" else "ONT(Fibre)"
        )

        self.fault_type.set(
            fault_type or "No Internet"
        )

        self.start_time.set(
            start_time or ""
        )

        self.affected_devices.set(
            affected_devices or ""
        )

        self.status.set(
            status or "Open"
        )

        self.escalated_to.set(
            escalated_to or "None"
        )

        self.ticket_number.set(
            ticket_number or ""
        )

        self.build_form()

        self.service_notes.insert(
            "1.0",
            service_notes or ""
        )

        self.notes.insert(
            "1.0",
            technician_notes or ""
        )

        self.customer_communication.insert(
            "1.0",
            customer_communication or ""
        )

        self.timeline = []

        if timeline:

            self.timeline = timeline.splitlines()

            for item in self.timeline:

                self.timeline_list.insert(
                    tk.END,
                    item
                )

        # Restore saved troubleshooting checkboxes (older records default to unchecked).
        try:
            saved_checks = json.loads(check_states or "{}")
        except (TypeError, json.JSONDecodeError):
            saved_checks = {}
        for name, variable in self.checks.items():
            variable.set(bool(saved_checks.get(name, False)))

        self.update_completion()

        messagebox.showinfo(
            "Fault Loaded",
            f"Fault #{record_id} loaded."
        )

    # ========================================================
    # NEW FAULT
    # ========================================================

    def new_fault(self):

        if self.current_fault_id:

            answer = messagebox.askyesno(
                "New Fault",
                "Start a new fault? Unsaved changes will be lost."
            )

            if not answer:
                return

        self.current_fault_id = None
        self.timeline = []

        self.customer.set("")
        self.site.set("")
        self.account.set("")
        self.reference.set("")

        self.service_type.set("ONT(Fibre)")

        self.fault_type.set(
            "No Internet"
        )

        self.start_time.set(
            datetime.now().strftime(
                "%Y-%m-%d %H:%M"
            )
        )

        self.affected_devices.set(
            "All devices"
        )

        self.status.set(
            "Open"
        )

        self.escalated_to.set(
            "None"
        )

        self.ticket_number.set(
            ""
        )

        for variable in self.checks.values():
            variable.set(False)

        self.build_form()

    # ========================================================
    # DASHBOARD
    # ========================================================

    def dashboard(self):

        window = tk.Toplevel(
            self.root
        )

        window.title(
            "FLC Dashboard"
        )

        window.geometry(
            "700x500"
        )

        title = tk.Label(
            window,
            text="FLC DASHBOARD",
            font=("Arial", 20, "bold")
        )

        title.pack(
            pady=20
        )

        conn = sqlite3.connect(
            DATABASE
        )

        cursor = conn.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM faults"
        )

        total = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM faults WHERE status='Open'"
        )

        open_count = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM faults WHERE status='Resolved'"
        )

        resolved = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM faults WHERE status='Escalated'"
        )

        escalated = cursor.fetchone()[0]

        cursor.execute(
            "SELECT COUNT(*) FROM faults WHERE status='Monitoring'"
        )

        monitoring = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COUNT(*)
            FROM faults
            WHERE DATE(created)=DATE('now')
        """)

        today = cursor.fetchone()[0]

        conn.close()

        stats = [
            ("Total Faults", total),
            ("Today's Faults", today),
            ("Open", open_count),
            ("Escalated", escalated),
            ("Monitoring", monitoring),
            ("Resolved", resolved),
        ]

        frame = tk.Frame(
            window
        )

        frame.pack(
            padx=30,
            pady=10
        )

        for index, (name, value) in enumerate(stats):

            card = tk.Frame(
                frame,
                bd=1,
                relief="solid",
                padx=25,
                pady=20
            )

            card.grid(
                row=index // 2,
                column=index % 2,
                padx=10,
                pady=10
            )

            tk.Label(
                card,
                text=str(value),
                font=("Arial", 25, "bold")
            ).pack()

            tk.Label(
                card,
                text=name,
                font=("Arial", 11)
            ).pack()

    # ========================================================
    # PDF EXPORT
    # ========================================================

    def export_pdf(self):

        filename = filedialog.asksaveasfilename(
            title="Save FLC PDF",
            defaultextension=".pdf",
            filetypes=[
                ("PDF files", "*.pdf")
            ]
        )

        if not filename:
            return

        styles = getSampleStyleSheet()

        document = SimpleDocTemplate(
            filename,
            pagesize=A4,
            rightMargin=40,
            leftMargin=40,
            topMargin=40,
            bottomMargin=40
        )

        story = []

        story.append(
            Paragraph(
                "FLC FAULT DOCUMENTATION",
                styles["Title"]
            )
        )

        story.append(
            Spacer(1, 15)
        )

        information = [
            ["Customer", self.customer.get()],
            ["Site", self.site.get()],
            ["Account", self.account.get()],
            ["Reference", self.reference.get()],
            ["Service", self.service_type.get()],
            ["Fault", self.fault_type.get()],
            ["Fault Started", self.start_time.get()],
            ["Affected Devices", self.affected_devices.get()],
            ["Status", self.status.get()],
            ["Escalated To", self.escalated_to.get()],
            ["Ticket", self.ticket_number.get() or "N/A"],
            ["FLC Completion", f"{self.completion.get()}%"],
        ]

        table = Table(
            information,
            colWidths=[150, 350]
        )

        table.setStyle(
            TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
                ("PADDING", (0, 0), (-1, -1), 7),
            ])
        )

        story.append(table)
        story.append(Spacer(1, 20))

        sections = [
            (
                "Service-Specific Findings",
                self.service_notes.get(
                    "1.0",
                    tk.END
                ).strip()
            ),
            (
                "Technician Findings",
                self.notes.get(
                    "1.0",
                    tk.END
                ).strip()
            ),
            (
                "Fault Timeline",
                "\n".join(self.timeline)
            ),
            (
                "Customer Communication",
                self.customer_communication.get(
                    "1.0",
                    tk.END
                ).strip()
            ),
        ]

        for title, content in sections:

            story.append(
                Paragraph(
                    title,
                    styles["Heading2"]
                )
            )

            if not content:
                content = "No information recorded."

            content = escape(content).replace("\n", "<br/>")

            story.append(
                Paragraph(
                    content,
                    styles["BodyText"]
                )
            )

            story.append(
                Spacer(1, 12)
            )

        document.build(
            story
        )

        messagebox.showinfo(
            "PDF Created",
            f"PDF successfully created:\n\n{filename}"
        )

# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = FLCApp(root)

    root.mainloop()
